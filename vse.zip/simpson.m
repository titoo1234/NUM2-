function Sf = simpson(h,f)
% Opis:
%  Funkcija simpson izracuna priblizek za integral funkcije s
%  sestavljenim Simpsonovim pravilom.
%
% Definicija:
%  Sf = simpson(h,f)
%
% Vhod:
%  h    dolzina koraka,
%  f    vrstica vrednosti funkcije v delilnih tockah.
%
% Izhod:
%  Sf   priblizek za integral funkcije, izracunan s sestavljenim
%       Simpsonovim pravilom.

Sf = f(1) + f(length(f));

for i = 1:(length(f)/2)
    
    Sf = Sf + 4*f(2*i);

end

for i = 1:(length(f)/2 - 1)
    Sf = Sf + 2*f(2*i+1);
    
end

Sf = Sf * h / 3;
