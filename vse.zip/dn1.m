
f = @(x) log(x);
M = [1 1 1; -1 1 3/2;1 1 2];
b = [f(1); f(3/2); f(2)];
x = linsolve(M,b)

a1 =  x(3)
b1 = x(2)
m1 = x(1)
a1+b1
% rezidual:
r = @(z) log(z) - x(3).*z - x(2);
%poiščemo max reziduala na int. [1,2]
xx = linspace(1,2,1001);
% plot(xx,r(xx))
% result = find(r(xx)==t);
m = max(r(xx));
index = find(r(xx)==m);
%y1 pri katerem je dosežena neskončna norma:
y1 = xx(index)
g = @(x) -r(x);
min = fminbnd(g,1,2)
%druga možnost
% d = @(z) 1./z - x(3)
% plot(xx,d(xx))
% nicla1 = fzero(d,1.5)

E2 = [1; min;2]
b2 = f(E2)
M2 = [1 1 1; -1 1 min;1 1 2]
x2 = linsolve(M,b)

a2 =  x2(3)
b2 = x2(2)
m2 = x2(1)

r2 = @(z) log(z) - x2(3).*z - x2(2);
d = @(z) 1./z - x2(3)
nicla = fzero(d,1.5)
% iščemo normo:
r2(nicla)
% fmax(r2,1,2)

