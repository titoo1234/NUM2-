t = [0,0,0,0,0];
h = pi/4;
for i = 1:5
    t(i) = sin(h*(i-1));
    
end

Tf = trapez(h,t)
Sf = simpson(h,t)