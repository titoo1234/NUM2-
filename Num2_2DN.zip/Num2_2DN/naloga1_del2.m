format long

f = @(x,y) y+15*exp(x)*cos(15*x);
y0 = 0;
r = 0;
h = 0.1*2^(-r);
x = 0:h:1;

% izracunani priblizki za dani r:
y = rk4(x,f,y0);

% tocne vrednosti
ft = @(x) exp(x)*sin(15*x);
yt = zeros(1, length(x));
for i=1:length(x)
    yt(i) = yt(i)+ft(x(i));
end


% a) globalna napaka
odgA = max(abs(y-yt))

razlikeR = zeros(1,5);
for r = 0:4
    h = 0.1*2^(-r);
    x = 0:h:1;

    % izracunani priblizki za dani r:
    y = rk4(x,f,y0);

    % tocne vrednosti
    ft = @(x) exp(x)*sin(15*x);
    yt = zeros(1, length(x));
    for i=1:length(x)
        yt(i) = yt(i)+ft(x(i));
    end


    % a) globalna napaka
    odgA = max(abs(y-yt));
    razlikeR(r+1) = odgA;
    
end
% $============================0HEUN

razlikeH = zeros(1,5);
for r = 0:4
    h = 0.1*2^(-r);
    x = 0:h:1;

    % izracunani priblizki za dani r:
    yh = heun(x,f,y0);

    % tocne vrednosti
    ft = @(x) exp(x)*sin(15*x);
    yt = zeros(1, length(x));
    for i=1:length(x)
        yt(i) = yt(i)+ft(x(i));
    end


    % a) globalna napaka
    odgA = max(abs(yh-yt));
    razlikeH(r+1) = odgA;
    
end
% b) heunova metoda



yh = heun(x,f,y0);
odgB = max(abs(yt-yh));


