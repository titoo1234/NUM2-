function Tf = trapez(h,fx)
% Opis:
%  Funkcija trapez izracuna priblizek za integral funkcije s sestavljenim
%  trapeznim pravilom.
%
% Definicija:
%  Tf = trapez(h,f)
%
% Vhod:
%  h    dolzina koraka,
%  f    vrstica vrednosti funkcije v delilnih tockah.
%
% Izhod:
%  Tf   priblizek za integral funkcije, izracunan s sestavljenim trapeznim
%       pravilom.

Tf = h/2*(fx(1)+2*sum(fx(2:end-1))+fx(end));

end