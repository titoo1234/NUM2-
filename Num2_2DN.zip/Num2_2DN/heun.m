function y = heun(x,f,y0) 
% Opis:
%  Funkcija heun vrne numericno resitev navadne diferencialne enacbe
%  y' = f(x,y) pri pogoju y(x(1)) = y0, ki je izracunana s Heunovo metodo.
%
% Definicija:
%  y = heun(x,f,y0)
%
% Vhodni podatki:
%  x    vrstica delilnih tock,
%  f    funkcija f v obliki @(x,y) f(x,y),
%  y0   zacetna vrednost resitve.
%
% Izhodni podatek:
%  y    vrstica numericnih priblizkov za vrednosti tocne resitve v delilnih
%       tockah.

gama = [1/2 1/2];

y = zeros(1,length(x));
y(1) = y0;
h = x(2) - x(1);

for n=2:length(x)
    k1 = f(x(n-1),y(n-1));
    k2 = f(x(n-1)+h,y(n-1)+h*k1);
    y(n) = y(n-1)+h*gama(1)*k1 + h*gama(2)*k2;
end
