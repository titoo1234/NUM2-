function odvod = diferenca(f, k, metoda, h, x0)
% Opis:
%  diferenca izračuna odvod funkcije f v točki x0 na podlagi diference, 
%  določene z metodo
%
% Definicija:
%  odvod = diferenca(f, k, metoda, h, x0)
%
% Vhodni podatki:
%  f        funkcija,
%  k        stopnja odvoda (k=1, razen pri simetrični diferenci za 2 odvod, kjer je k=2),
%  metoda   metoda za izračun odvoda (prema, obratna ali simetrična diferenca),
%  h        korak,
%  x0       točka, v kateri nas zanima odvod funkcije f. 
%
% Izhodni podatek:
%  odvod    odvod funkcije f v točki x0 izračunan z ustrezno metodo.

if k == 1
    odvod = zeros(1,4);
    if metoda == "prema"
        for i=1:4
            odvod(i)=(f(x0+h(i))-f(x0))/h(i);
        end
    end
    if metoda == "obratna"
        for i=1:4
            odvod(i)=((f(x0)-f(x0-h(i)))/h(i));
        end
    end
    if metoda == "simetricna"
        for i=1:4
            odvod(i)=(f(x0+h(i))-f(x0-h(i)))/(2*h(i));
        end
    end
end


if k == 2
    odvod = zeros(1,4);
    for i=1:4
        odvod(i) = (f(x0-h(i))-2*f(x0)+f(x0+h(i)))/(h(i)*h(i));
    end
end

end
