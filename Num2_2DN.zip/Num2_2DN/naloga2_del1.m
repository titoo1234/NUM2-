format long

f = @(x) sin(x);
a = 0;
b = pi;
k1 = 4;
k2 = 2;

% odgovor a)
[p1,S1] = romberg(f,a,b,k1);

% odgovor b)
[p2,S2] = romberg(f,a,b,k2);
If = integral(f,a,b,'RelTol',1e-10,'AbsTol',1e-14);
napaka = abs(p2-If);