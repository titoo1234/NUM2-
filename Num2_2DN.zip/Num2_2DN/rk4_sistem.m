function y =rk4_sistem(x,f,y0)
% Opis:
%  Funkcija rk4 vrne numericno resitev navadne diferencialne enacbe
%  y' = f(x,y) pri pogoju y(x(1)) = y0, ki je izracunana z Runge-Kutta metodo stopnje 4.
%
% Definicija:
%  y = rk4(x,f,y0)
%
% Vhodni podatki:
%  x    vrstica delilnih tock,
%  f    funkcija f v obliki @(x,y) f(x,y),
%  y0   zacetna vrednost resitve.
%
% Izhodni podatek:
%  y    vrstica numericnih priblizkov za vrednosti tocne resitve v delilnih
%       tockah.

gama = [1/6 2/6 2/6 1/6];

y = zeros(2,length(x));
y(:,1) = y0;
h = x(2)-x(1);

for n=2:length(x)
    k1 = f(x(n-1),y(:,n-1));
    k2 = f(x(n-1)+h/2,y(:,n-1)+h/2*k1);
    k3 = f(x(n-1)+h/2,y(:,n-1)+h/2*k2);
    k4 = f(x(n-1)+h,y(:,n-1)+h*k3);
    y(:,n) = y(:,n-1)+h*(gama(1)*k1+gama(2)*k2+gama(3)*k3+gama(4)*k4);
end

end

    
