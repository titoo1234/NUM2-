function [p,S] = romberg(f,a,b,k)
% Opis:
%  Funkcija romberg izracuna priblizek za integral funkcije f na intervalu
%  [a,b] po k korakih rombergove metode.
%
% Definicija:
%  [p,S] = romberg(f,a,b,k)
%
% Vhod:
%  f    funkcija,
%  a,b  zacetek in konec intervala,
%  k    stevilo korakov.
%
% Izhod:
%  p   priblizek za integral funkcije f, dobljen po k korakih rombergove
%      metode
%  S   shema izracunanih priblizkov 

k_st = 1:k;
m = zeros(1,k);
trapezi = zeros(1,k);
simpsoni = zeros(1,k);
for i=1:k
    m(i) = 2^k_st(i);
    h = (b-a)/m(i);
    x = a:h:b;
    fx = zeros(1,length(x));
    for j=1:length(x)
        fx(j) = f(x(j));
    end
    trapezi(i) = trapez(h,fx);
    simpsoni(i) = simpson(h,fx);
end

S = zeros(k+1,k+1);
for i=2:k+1
    S(i,1) = trapezi(i-1);
    S(i,2) = simpsoni(i-1);
end

for j=3:k+1
    for i=j:k+1
        S(i,j) = (2^(2*(j-1))*S(i,j-1)-S(i-1,j-1))/(2^(2*(j-1))-1);
    end
end
p = S(k+1,k+1);
end
