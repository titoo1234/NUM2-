format long

alfa = 10;
beta = 1;
gama = 8;
delta = 1;
h = 0.1;
t = 0:h:5;

f = @(t,y) [alfa*y(1)-beta*y(1)*y(2); delta*y(1)*y(2)-gama*y(2)];
y0 = [2; 10];

% točni približki
res_tocni = ode45(f,[0 5],y0,odeset('RelTol',1e-12,'AbsTol',1e-14));
tocni = deval(res_tocni,t);
tocni_pleni = tocni(1,:)';
tocni_plenilci = tocni(2,:)';

plen = rk4_sistem(t,f,y0);
stevilo_plenov = plen(1,:)';
stevilo_plenilcev = plen(2,:)';

% napake
napaka_plen = abs(stevilo_plenov-tocni_pleni);
napaka_plenilci = abs(stevilo_plenilcev-tocni_plenilci);
