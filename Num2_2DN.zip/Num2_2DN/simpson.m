function Sf = simpson(h,fx)
% Opis:
%  Funkcija simpson izracuna priblizek za integral funkcije s
%  sestavljenim Simpsonovim pravilom.
%
% Definicija:
%  Sf = simpson(h,f)
%
% Vhod:
%  h    dolzina koraka,
%  f    vrstica vrednosti funkcije v delilnih tockah.
%
% Izhod:
%  Sf   priblizek za integral funkcije, izracunan s sestavljenim
%       Simpsonovim pravilom.

Sf = h/3*(fx(1)+4*sum(fx(2:2:end-1))+2*sum(fx(3:2:end-2))+fx(end));

end