format long
% Implementirajte sledeče pravilo za izračun odvoda funkcije f v točki x0:

f = @(x) 1./(x+1);
odvodf = @(x) -1/(x + 1)^2;
x0 = 1/2;
h = [0.01 0.1 0.15 0.2];
fx = zeros(1,4);
% pravlo = @(x) 1/(12*h(i))*f(x0-2*h(i))-2/(3*h(i))*f(x0-h(i))+2/(3*h(i))*f(x0+h(i))-1/(12*h(i))*f(x0+2*h(i))
% približki
for i=1:4
    fx(i)=1/(12*h(i))*f(x0-2*h(i))-2/(3*h(i))*f(x0-h(i))+2/(3*h(i))*f(x0+h(i))-1/(12*h(i))*f(x0+2*h(i));
end
odgA = fx

tocna_vrednost = odvodf(x0)

% napake
napake = zeros(1,4);
for i=1:4
    napake(i) = abs(fx(i)-tocna_vrednost);
end
odgB = napake

% diference

prema = diferenca_dn(f,1,"prema",h,x0);
razlike_prema = zeros(1,4);
for i=1:4
    razlike_prema(i)=abs(prema(i)-fx(i));
end
odgB_prema = razlike_prema;

obratna = diferenca_dn(f,1,"obratna",h,x0);
razlike_obratna = zeros(1,4);
for i=1:4
    razlike_obratna(i)=abs(obratna(i)-fx(i));
end
% razlike_obratna = abs(obratna - fx) BPLJŠE
odgB_obratna = razlike_obratna;

simetricna = diferenca_dn(f,1,"simetricna",h,x0);
razlike_simetricna = zeros(1,4);
for i=1:4
    razlike_simetricna(i)=abs(simetricna(i)-fx(i));
end
odgB_simetricna = razlike_simetricna;

